<?php
/**
 * Created by PhpStorm.
 * User: dirky91
 * Date: 2019/5/16
 * Time: 15:13
 */

namespace app\http;


use think\worker\Events;

class Server extends Events
{

}