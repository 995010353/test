<?php
namespace app\index\controller;

use think\Console;
use Workerman\Worker;

class Index
{
    public function index()
    {
         return phpinfo();
    }

    public function hello($name = 'ThinkPHP5')
    {
        return 'hello,' . $name;
    }
}
